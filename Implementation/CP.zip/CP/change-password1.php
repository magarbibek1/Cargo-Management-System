<?php

require("php/user.php");
 
if(!isset($_SESSION['Id1']))
{
   header("location:login1.php");
}
if(isset($_SESSION['Id1']))
{
 $id = $_SESSION['Id1']; //2
 $obj = new user;
 $obj->setID($id);
 $data = $obj->selectUser();

 $name=$data['name'];
 $emal=$data['email'];
 $dob=$data['date'];
 $address=$data['address'];
 $country=$data['country'];
 $postal=$data['postal'];
 $username=$data['username'];
 $gender=$data['gender'];
 $security=$data['security'];
 $Password=$data['Password'];
 $id=$data['Id'];
}
?>

<?php 
   if(isset($_GET['msg1']) && $_GET['msg1']=='passwordnotmatch'){
    echo "<script> alert('Password did not matched') </script>";
  }
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>cargo management system</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/change-password.css" type="text/css">
</head>
	<body>
		<header>
			<div class="navigation">
		  <ul>
		 <li>
					<a href="profile.php">profile</a>
 
				</li>
				
				<li>
					<a class="active" href="change-password1.php">changepass</a>
 
				</li>
				
				
				<li>
					<a href="updateprofile.php">update</a>
 
				</li>
				
				<li>
					<a href="cargo1.php">cargo</a>
			
				</li>
				<li>
					<a  href="private.php">private</a>
 
				</li>
				
				<li>
					<a href="php/logoutuser.php">Logout</a>
 
				</li>
          </ul>
		</div>
		</header>

		<div class="login-box">
			<img src="images/pass.png" class="user" alt="user">
			<h1>Change Password</h1>

			<form method="post" action="php/action.php">
				<p class="user1"><label>username: <?php echo $data['username']; ?></label></p>
				<p><label>Security Code</label></p>
				<p><input type="text" name="security" placeholder="Enter Security Code" required=""></p>
				<p><label>New Password</label></p>
				<p><input type="Password" name="pass" placeholder="Enter new Password" required=""></p>
				<p><label>Conform Password</label></p>
				<p><input type="text" name="repass" placeholder="Re-enter Password" required=""></p>
				<p><input type="hidden" name="userid" value="<?php echo $id ?>"></p>
				<p><input type="submit" name="password-submit" value="Change Password"></p>

			</form>
		</div>
		<footer>
			<div class="foot">
				<p>cargo management system Pvt.Ltd &#169; 2019<br>Designed by:Bibek Rana Magar</p>

			</div>
		</footer>
	</body>
</html>