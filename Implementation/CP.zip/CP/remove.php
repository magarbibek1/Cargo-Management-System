
<?php
$conn = mysqli_connect("localhost","root","","magar");
$id=$_GET['idp'];
$query= "delete from cargodetails where id=$id";
mysqli_query($conn,$query);
header("location:updatecargo.php");
  ?>
  
 