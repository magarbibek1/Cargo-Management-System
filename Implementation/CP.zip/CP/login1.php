<?php 
session_start();
if(isset($_SESSION['Id2'])){
	header("location:admin.php");
}
elseif(isset($_SESSION['Id1'])){
	header("location:private.php");
}

 ?>

<?php

 
  if(isset($_GET['msg2']) && $_GET['msg2']=='passwordchanged'){
    echo "<script> alert('Password changed') </script>";
  }
  
  if(isset($_GET['register']) && $_GET['register']=='user-reg'){
    echo "<script> alert('User Register succesfully') </script>";
  }


  if(isset($_GET['msg']) && $_GET['msg']=='invalidlogin'){
    echo "<script> alert('Invalid Username and password') </script>";
  }
 

      if(isset($_COOKIE['count']) && $_COOKIE['count']>2)
      {
        echo "<script> alert('you are blocked for 5 minutes')</script>";
        die();
      }
	?>



<!DOCTYPE html>
<html lang="en">
<head>
	<title>cargo management system</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/login.css" type="text/css">
</head>
	<body>
		<header>
			<div class="navigation">
		  <ul>
             
            <li class="nav-last"><a href="login.php">Admin LogIn</a></li>
            <li class="nav-last"><a href="register.php">Register</a></li>
          </ul>
		</div>
		</header>

		<div class="login-box">
			<img src="images/user.png" class="user" alt="user">
			<h1>Log   In</h1>
			<form method="post" action="php/action.php">
				<p><label>Username</label></p>
				<p><input type="text" id="user" name="user" placeholder="Enter Username" required></p>
				<p><label>Password</label></p>
				<p><input type="Password" id="pass" name="pass" placeholder="Enter Password" required></p>
				<p><input type="checkbox" onclick="myFunction()">Show Password</p>

				<p><input type="submit" id="btn" name="login" value="Sign In"></p>
				<p><a href="forget-password.php">Forget Password</a></p>
			</form>

<script>
 function myFunction() {
 var x = document.getElementById("pass");
   if (x.type === "password") {
      x.type = "text";
    } else {
        x.type = "password";
    }
}
</script>
		</div>
		<footer>
			<div class="foot">
				<p>Eco-Friendly Cars Pvt.Ltd &#169; 2019<br>Designed by: Bibek Rana Magar</p>

			</div>
		</footer>
	</body>
</html>