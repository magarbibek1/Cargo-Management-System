<?php 
session_start();
session_destroy();
unset($_SESSION['Id1']);
unset($_SESSION['Id2']);
header("location:../index.php")

 ?>