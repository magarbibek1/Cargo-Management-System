<?php
session_start();
  require("connection.php");
  class user extends connection{
    public $id;
    public $name;
    public $email;
    public $country;
    public $address;
    public $dob;
    public $security;
    public $postal;
    public $username;
    public $gender;
    public $password;
    public $cpassword;
    public $usertype="general";

    public function setID($id){
    $this->id=$id;
  }

    public function setname($name){
    $this->name=$name;
  }

  public function setemail($email){
    $this->email=$email;
  }
  public function setcountry($country){
    $this->country=$country;
  }

  public function setaddress($address){
    $this->address=$address;
  }
  public function setdob($dob){
    $this->dob=$dob;
  }

  public function setsecurity($security){
    $this->security=$security;
  }
  public function setpostal($postal){
    $this->postal=$postal;
  }

  public function setusername($username){
    $this->username=$username;
  }
  public function setgender($gender){
    $this->gender=$gender;
  }

  public function setpassword($password){
    $this->password=$password;
  }
  public function setcpassword($cpassword){
    $this->cpassword=$cpassword;
  }


public function insert(){
  $selectuser="select * from tbl_register where username='$this->username'";
  $resultuser = mysqli_query($this->conn,$selectuser);
  $checkusername=mysqli_num_rows($resultuser);

      if ($checkusername>0) {
          header("location:../register.php?user=userexist");
      }
      else {
         $query="insert into tbl_register values(NULL,'$this->name','$this->email','$this->country','$this->address','$this->dob','$this->security','$this->postal','$this->username','$this->gender','$this->password','$this->usertype')";
           mysqli_query($this->conn,$query);
           header("location:../login.php?register=user-reg");
      }
  

     
  }



  public function login(){
if(isset($_COOKIE['count']) && $_COOKIE['count']>2)
      {
        echo "<script> alert('you are blocked for 5 minutes')</script>";
        die();
      }

    $query="select * from tbl_register where username='$this->username' and password='$this->password'";
    $res=mysqli_query($this->conn,$query);
    $count=mysqli_num_rows($res);

    if($count>0)
    {
      $data=mysqli_fetch_array($res);

      $usertype=$data['usertype'];
       $id=$data['Id'];
      
      

      if($usertype=="admin") //admin login
      { 
        $_SESSION['Id2'] = $id;
      header("location:../forum.php"); 
        
      }
      else
      {
      // general user login
        $_SESSION['Id1'] = $id;
        header("location:../profile.php");
      }

    }
    else
    {
      header("location:../login.php?msg=invalidlogin");
      if(isset($_COOKIE['count']))
    {
      if($_COOKIE['count']<=2)
      {
        $new_counter=$_COOKIE['count']+1;
        setcookie('count', $new_counter,time()+300); 
      }
      
    }
    else
    {
    $counter=1;
    setcookie('count',$counter);
    }
      


    }
  }

  public function selectUser()
  {
      $query = "select * from tbl_register where Id='$this->id'";
      $res = mysqli_query($this->conn,$query);
      $data = mysqli_fetch_array($res);
      return $data;
     
  }
  public function Changepassword(){
      $query = "select * from tbl_register where Id='$this->id' && security='$this->security'";
      $res = mysqli_query($this->conn,$query);
      $securitychk=mysqli_num_rows($res);

      if ($securitychk>0) {
        if($this->password==$this->cpassword){
          $update="update tbl_register set password='$this->password' where Id='$this->id'";
          mysqli_query($this->conn,$update);
          
        }
        else{
          header("location:../change-password.php?msg1=passwordnotmatch");
        }
      }
      else{
         echo "<script> alert('security code didnt matched')</script>";
      }
  }

   

   public function Updateprofile(){
    $updatee="update tbl_register set name='$this->name',email='$this->email',country='$this->country',address='$this->address',postal='$this->postal',security='$this->security' where Id='$this->id'"; 
    mysqli_query($this->conn,$updatee);
   }
}



  class userpost extends connection{
  public $pid;
  public $post;
  public $uname;


  public function setpost($post){
    $this->post=$post;
  }
  public function setuname($uname){
    $this->uname=$uname;
  }


  public function InsertPost(){
    $query="insert into tbl_post(post,username) values ('$this->post','$this->uname')";
    mysqli_query($this->conn,$query);

  }

  public function SelectPost(){
    $query1="select * from tbl_post";
    $results1=mysqli_query($this->conn,$query1);
    return $results1;

  }
}

class usercomment extends connection{
  public $c_id;
  public $comment;
  public $postid;
  public $username;

  public function setcomment($comment){
    $this->comment=$comment;
  }
  public function setpostid($postid){
    $this->postid=$postid;
  }
  public function setusername($username){
    $this->username=$username;
  }


  public function PostComment(){
    $query="insert into tbl_post_comment(comment,p_id,username) values ('$this->comment','$this->postid','$this->username')";
    mysqli_query($this->conn,$query);
  }

  public function SelectComment(){
    $query2="select * from tbl_post_comment where p_id='$this->postid'";
    $results2=mysqli_query($this->conn,$query2);
    return $results2;
  }


}


class Counterview extends connection{
   public function Uservieww(){
    $select5="select * from tbl_counter_view where id=1";
    $viewresult=mysqli_query($this->conn,$select5);
    $view=0;
    while ($viewvalue=mysqli_fetch_array($viewresult)) {
      $view=$viewvalue['userview'];
      
    }
    $updateview="update tbl_counter_view set userview=userview+1 where id=1";
    mysqli_query($this->conn,$updateview);
    return $view;
   }

}


  
 

?>