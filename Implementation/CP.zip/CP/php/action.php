<?php
require("user.php");
$obj=new user;
 if (isset($_POST['register']))
 {
 	$name=$_POST['name'];
 	$email=$_POST['email'];
 	$country=$_POST['country'];
 	$address=$_POST['address'];
 	$dob=$_POST['dob'];
 	$security=$_POST['security'];
 	$postal=$_POST['code'];
 	$username=$_POST['user'];
 	$gender=$_POST['gender'];
 	$password=$_POST['pass'];


 	$obj->setname($name);
 	$obj->setemail($email);
 	$obj->setcountry($country);
 	$obj->setaddress($address);
 	$obj->setdob($dob);
 	$obj->setsecurity($security);
 	$obj->setpostal($postal);
 	$obj->setusername($username);
 	$obj->setgender($gender);
 	$obj->setpassword($password);

 	$obj->insert();
 	

}

if (isset($_POST['uprofile']))
 {
 	$id=$_POST['iduser'];
 	$name=$_POST['name'];
 	$email=$_POST['email'];
 	$country=$_POST['country'];
 	$address=$_POST['address'];
 	$security=$_POST['security'];
 	$postal=$_POST['code'];

    $obj->setId($id);
 	$obj->setname($name);
 	$obj->setemail($email);
 	$obj->setcountry($country);
 	$obj->setaddress($address);
 	$obj->setsecurity($security);
 	$obj->setpostal($postal);

 	$obj->Updateprofile();
 	header("location:../private.php?msg3=update");

}

if (isset($_POST['login']))
{
	$username=$_POST['user'];
 	$password=$_POST['pass'];

 	$obj->setusername($username);
 	$obj->setpassword($password);

 	$obj->login();
}
if(isset($_POST['password-submit'])){
	$id=$_POST['userid'];
	$security=$_POST['security'];
	$password=$_POST['pass'];
	$cpassword=$_POST['repass'];
    
    $obj->setId($id);
	$obj->setsecurity($security);
	$obj->setpassword($password);
	$obj->setcpassword($cpassword);

	$obj->Changepassword();
	session_unset($_SESSION['Id1']);
    header("location:../login.php?msg2=passwordchanged");
}

if(isset($_POST['upost'])){
    $obj=new userpost;
	$post=$_POST['postarea'];
	$uname=$_POST['name'];

	$obj->setpost($post);
 	$obj->setuname($uname);

 	$obj->InsertPost();
 	header("location:../private.php");

} 

if(isset($_POST['comment'])){
	$obj=new usercomment;
	$comment=$_POST['commentarea'];
	$username=$_POST['namee'];
	$postid=$_POST['postid'];

	$obj->setcomment($comment);
	$obj->setusername($username);
	$obj->setpostid($postid);

	$obj->PostComment();
	header("location:../private.php");

}


	
	
	
	
	
	
	
	
	
	

 	




 ?>

