<?php  
class connection
{
	private $username="root";
	private $hostname="localhost";
	private $password="";
	private $dbname="narayancpproject";
	protected $conn;
	public function __Construct()
	{
		$this->conn =mysqli_connect($this->hostname,$this->username,$this->password,$this->dbname);
	}
}
?>