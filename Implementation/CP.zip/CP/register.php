<?php 
session_start();
if(isset($_SESSION['Id2'])){
  header("location:admin.php");
}
elseif(isset($_SESSION['Id1'])){
  header("location:private.php");
}

if(isset($_GET['user']) && $_GET['user']=='userexist'){
    echo "<script> alert('Username Already exist, try diffrent') </script>";
  }
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>cargo management system</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/register.css" type="text/css">
</head>
<body>
  <header>
		<div class="navigation">
		  <ul>
            <li class="nav-last"><a href="login.php">Admin LogIn</a></li>
            <li class="nav-last"><a href="register.php">Register</a></li>
          </ul>
		</div>
  </header>

  <div class="reg-box">
  	<img src="images/user.png" class="user" alt="user">
	<h1>Register Here</h1>
<form method="post" action="php/action.php">
<table>
  <tr>
    <td>
    	<p><label>Name</label></p>
      	<p><input type="text" name="name" placeholder="Enter Your Full Name" required=""></p>
    </td>
    <td>
    	<p><label>Email</label></p>
      	<p><input type="text" name="email" placeholder="Something@example.com" required=""></p>
    </td>
  </tr>
  <tr>
  	<td>
  		<p><label>Country</label></p>
      	<p><input type="text" name="country" placeholder="Enter Your Country" required=""></p>
  	</td>
  	<td>
  		<p><label>Address</label></p>
      	<p><input type="text" name="address" placeholder="Enter Your Address" required=""></p>
  	</td>
  </tr>
  <tr>
  	<td>
  		<p><label>Date Of Birth</label></p>
      	<p><input type="Date" name="dob" placeholder="YYYY-MM-DD" required=""></p>
  	</td>
  	<td>
  		<p><label>Security Code</label></p>
      	<p><input type="text" name="security" placeholder="Enter Security Code" required=""></p>
  		
  	</td>
  </tr>
  <tr>
  	<td>
  		<p><label>Postal Code</label></p>
      	<p><input type="text" name="code" placeholder="Enter Your Postal Code" required=""></p>
  	</td>
  	<td>
  		<p><label>UserName</label></p>
      	<p><input type="text" name="user" placeholder="Enter Your UserName" required=""></p>
  	</td>
  </tr>
  <tr>
  	<td>
  		<p><label>Gender</label>
      	<p>
         <select name="gender">
         <option value="male">Male</option>
         <option value="female">Female</option>
         <option value="Others">Others</option>
        </select> 
        </p>
  	</td>
  	<td>
  		<p><label>Password</label></p>
      	<p><input type="text" name="pass" placeholder="Enter Password" required=""></p>
  	</td>
  </tr>
</table>
<p><input type="submit" name="register" value="Register"></p>
</form>

  </div>

  <footer>
    <div class="foot">
	 <p>Cargo management Pvt.Ltd &#169; 2019<br>Designed by: Bibek Rana Magar</p>
	</div>
</footer>
</body>
</html>