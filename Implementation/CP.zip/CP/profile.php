<?php

require("php/user.php");
 
if(!isset($_SESSION['Id1']))
{
   header("location:login1.php");
}

if(isset($_SESSION['Id1']))
{
 $id = $_SESSION['Id1']; //2
 $obj = new user;
 $obj->setID($id);
 $data = $obj->selectUser();

 $name=$data['name'];
 $emal=$data['email'];
 $dob=$data['date'];
 $address=$data['address'];
 $country=$data['country'];
 $postal=$data['postal'];
 $username=$data['username'];
 $gender=$data['gender'];
 
}
 $objectp = new userpost;
 $status = $objectp->SelectPost();
?>
<!DOCTYPE html>
<html lang="en">
<head>


	<title>cargo management system</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/profile.css" type="text/css">
</head>
<body>
		<header>
		<div class="navigation">
		   <ul>
		   <li>
					<a class="active"href="profile.php">profile</a>
 
				</li>
				
				<li>
					<a href="change-password1.php">changepass</a>
 
				</li>
				
				
				<li>
					<a href="updateprofile.php">update</a>
 
				</li>
				
				<li>
					<a href="cargo1.php">cargo</a>
			
				</li>
				<li>
					<a  href="private.php">private</a>
 
				</li>
				
				<li>
					<a href="php/logoutuser.php">Logout</a>
 
				</li>
          </ul>
		</div>
		</header>
  <div class="online" >
			<h1>Welcome to your profile..!</h1>
		</div>
		<div class="profile" id="section2">
			<div class="dp">
				<img src="images/dp.png">
			</div>

			<h1>Welcome <?php echo $username; ?></h1>
			<p><b>Name:</b><?php echo $name; ?></p>
			<p><b>Gender:</b> <?php echo $gender; ?></p>
			<p><b>Date of Birth:</b> <?php echo $dob; ?></p>
			<p><b>Age:</b>
               <?php 
                  $dateofbirth=new DateTime($dob);
                  $agetoday=new DateTime('Y.01.01');
                  echo $dateofbirth->diff($agetoday)->y
                ?>
			</p>
			<p><b>Email:</b> <?php echo $emal; ?></p>
			<p><b>Country:</b> <?php echo $country; ?></p>
			<p><b>Address:</b> <?php echo $address; ?></p>
			<p><b>Postal Code:</b> <?php echo $postal; ?></p>
		</div>
		 

</body>
</html>