
<?php
$con = mysqli_connect('127.0.0.1','root','');
if(!$con)
{
	echo 'not connected to server';
}
if (!mysqli_select_db($con,'magar'))
{
	echo 'database not selected';
}
    $sendername=$_POST['sendername'];
    $senderemail=$_POST['senderemail'];
    $sendercontact=$_POST['sendercontact'];
 	$senderpin=$_POST['senderpin'];
 	$sendercountry=$_POST['sendercountry'];
 	$sendercity=$_POST['sendercity'];
 	$senderaddress=$_POST['senderaddress'];
	$recivername=$_POST['recivername'];
    $reciveremail=$_POST['reciveremail'];
    $recivercontact=$_POST['recivercontact'];
 	$reciverpin=$_POST['reciverpin'];
 	$recivercountry=$_POST['recivercountry'];
 	$recivercity=$_POST['recivercity'];
 	$reciveraddress=$_POST['reciveraddress'];
	$weight=$_POST['weight'];
    $height=$_POST['height'];
    $width=$_POST['width'];
    $length=$_POST['length'];
    $quantity=$_POST['quantity'];
    $cargotype=$_POST['cargotype'];
 	
$sql = "INSERT INTO cargodetails (sendername,senderemail,sendercontact,senderpin,sendercountry,sendercity,senderaddress,recivername,reciveremail,recivercontact,reciverpin,recivercountry,recivercity,reciveraddress,weight,height,width,length,quantity,cargotype) VALUES ('$sendername','$senderemail','$sendercontact','$senderpin','$sendercountry','$sendercity','$senderaddress','$recivername','$reciveremail','$recivercontact','$reciverpin','$recivercountry','$recivercity','$reciveraddress','$weight','$height','$width','$length','$quantity','$cargotype')";

if(!mysqli_query($con,$sql))
{
	echo 'not inserted';
}
else
{
	echo 'inserted';
}
  header("refresh:1; url=profile.php");
?>
