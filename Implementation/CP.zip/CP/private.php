<?php

require("php/user.php");
 
if(!isset($_SESSION['Id1']))
{
   header("location:login1.php");
}

if(isset($_SESSION['Id1']))
{
 $id = $_SESSION['Id1']; //2
 $obj = new user;
 $obj->setID($id);
 $data = $obj->selectUser();

 $name=$data['name'];
 $emal=$data['email'];
 $dob=$data['date'];
 $address=$data['address'];
 $country=$data['country'];
 $postal=$data['postal'];
 $username=$data['username'];
 $gender=$data['gender'];
 
}
 $objectp = new userpost;
 $status = $objectp->SelectPost();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("a").on('click', function(event) {
    if (this.hash !== "") {
      
      event.preventDefault();

      var hash = this.hash;

      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 600, function(){
   
        window.location.hash = hash;
      });
    } 
  });
});
</script>


	<title>cargo management system</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/private.css" type="text/css">
</head>
<body>
		<header>
			<div class="navigation">
			
			 <ul>
<li>
					<a href="profile.php">profile</a>
 
				</li>
				
				<li>
					<a href="change-password1.php">changepass</a>
 
				</li>
				
				
				<li>
					<a href="updateprofile.php">update</a>
 
				</li>
				
				<li>
					<a href="cargo1.php">cargo</a>
			
				</li>
				<li>
					<a class="active" href="private.php">private</a>
 
				</li>
				
				<li>
					<a href="php/logoutuser.php">Logout</a>
 
				</li>
          </ul>
 
		</div>
		</header>
         
          <div class="arrowup">
		 	<a href="#section2"><img src="image/pup.png"></a> 
		 </div>
		 <div class="bbb" id="section2">
		 	
		 </div>
		<div class="online" >
			<h1>Welcome to Online Community Forum..!</h1>
		</div>
		<div class="news">
			<h1>Welcome <?php echo $username; ?></h1>
			<p>Hey <b><?php echo $name; ?></b> here you can write a query on any cargo. </p>
             <h2>Write Post</h2>
			<form method="post" action="php/action.php">
				<textarea name="postarea" placeholder="Write Post.."></textarea>
		      <input type="Submit" name="upost" value="Post">
		      <input type="hidden" name="name" value="<?php echo $username ?>">
			</form>

		</div>


          <?php 
         
          foreach($status as $postsss){

           ?>
		<div class="feeds">

			<div class="userdetail">
				<h1><img src="image/upost.png"> <?php echo $postsss['username']; ?></h1>
			</div>
			
			<div class="post">
				<?php echo $postsss['post']; ?>
			</div>
			

			<div class="comment">
				Comment
			</div>
             
            <?php
            $posttttid=$postsss['id'];
             $objcomment = new usercomment;
             $objcomment->setpostid($posttttid);
             $comments = $objcomment->SelectComment();
            
          foreach($comments as $ucomment){

           ?> 
			<div class="usercomment">
					<p><b><?php echo $ucomment['username']; ?></b>: <?php echo $ucomment['comment']; ?></p>
				</div>
				<?php } ?>
			

			<div class="commentbox">
				<form method="post" action="php/action.php">
					<p>
					
					<input type="text" name="commentarea" placeholder="Write your comment"> <input type="submit" name="comment" value="Comment">
					<input type="hidden" name="namee" value="<?php echo $username ?>">
					<input type="hidden" name="postid" value="<?php echo $posttttid ?>">
				</p>
				</form>
			</div>
		</div>
		<?php 
	}

		 ?>
		

		
</body>
</html>