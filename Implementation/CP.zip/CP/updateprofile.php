
<?php
require("php/user.php");
if(!isset($_SESSION['Id1']))
{
   header("location:login1.php");
}
if(isset($_SESSION['Id1']))
{
 $id = $_SESSION['Id1']; //2
 $obj = new user;
 $obj->setID($id);
 $data = $obj->selectUser();

 $name=$data['name'];
 $emal=$data['email'];
 $dob=$data['date'];
 $address=$data['address'];
 $country=$data['country'];
 $postal=$data['postal'];
 $username=$data['username'];
 $gender=$data['gender'];
 $security=$data['security'];
 $Password=$data['Password'];
 $id=$data['Id'];
}

 if(isset($_GET['msg3']) && $_GET['msg3']=='update'){
    echo "<script> alert('profile Updated succesfully') </script>";
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>cargomanagement system</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/updateprofile.css" type="text/css">
</head>
<body>
  <header>
      <div class="navigation">
      <ul>
	<li>
					<a href="profile.php">profile</a>
 
				</li>
				
				<li>
					<a href="change-password1.php">changepass</a>
 
				</li>
				
				
				<li>
					<a class="active"href="updateprofile.php">update</a>
 
				</li>
				
				<li>
					<a href="cargo1.php">cargo</a>
			
				</li>
				<li>
					<a  href="private.php">private</a>
 
				</li>
				
				<li>
					<a href="php/logoutuser.php">Logout</a>
 
				</li>
          </ul>
		  
		  
		  
    </div>
    </header>

  <div class="login-box">
  	<img src="images/update.png" class="user" alt="user">
	<h1>Update Profile</h1>
<form method="post" action="php/action.php">
  <p class="user1"><label><?php echo $data['username']; ?></label></p>
<table>
  <tr>
    <td>
    	<p><label>Name</label></p>
      	<p><input type="text" name="name" placeholder="<?php echo $data['name']; ?>" required=""></p>
    </td>
    <td>
    	<p><label>Email</label></p>
      	<p><input type="text" name="email" placeholder="<?php echo $data['email']; ?>" required=""></p>
    </td>
  </tr>
  <tr>
  	<td>
  		<p><label>Country</label></p>
      	<p><input type="text" name="country" placeholder="<?php echo $data['country']; ?>" required=""></p>
  	</td>
  	<td>
  		<p><label>Address</label></p>
      	<p><input type="text" name="address" placeholder="<?php echo $data['address']; ?>" required=""></p>
  	</td>
  </tr>
  <tr>
  	<td>
  		<p><label>Postal Code</label></p>
        <p><input type="text" name="code" placeholder="<?php echo $data['postal']; ?>" required=""></p>
  	</td>
  	<td>
  		<p><label>Security Code</label></p>
      	<p><input type="text" name="security" placeholder="<?php echo $data['security']; ?>" required=""></p>
  		
  	</td>
  </tr>

</table>
<p><input type="hidden" name="iduser" value="<?php echo $id ?>"></p>
<p><input type="submit" name="uprofile" value="Update Profile"></p>
</form>
<br>

  </div>
  	<footer>
			<div class="foot">
				<p>cargo management system Pvt.Ltd &#169; 2017<br>Designed by: Narayan giri</p>

			</div>
		</footer>
</body>
</html>
